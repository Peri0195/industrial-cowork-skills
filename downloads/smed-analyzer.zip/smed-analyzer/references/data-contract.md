# 输入输出契约

任务：换型内外作业改善核算。

## 字段结构
以下字段均需提供，嵌套数组可增加同结构记录。数组需非空，ID不可重复；数值不接收字符串、布尔值、NaN或无穷大。非负和正值限制由脚本逐字段检查；允许负收益的payoff等字段另有处理。
```json
{
  "before_internal_minutes": [
    10,
    20,
    5
  ],
  "after_internal_minutes": [
    8,
    10,
    2
  ]
}
```
字段名单位：minutes为分钟，hours为小时，days为天，kg为千克，m3为立方米，ton_km为吨公里，fraction及rate为小数比例（具体范围见方法）。amount、cost、payoff须使用同一种币种。日期为YYYY-MM-DD。

## 方法和边界
改善前停机=sum(before_internal_minutes)；改善后=sum(after_internal_minutes)；外作业并行能力由现场另行确认。

只核算时间，不假设移到机外的作业无需资源。

## 样例输出校验点
```json
{
  "saved_minutes": 15,
  "reduction_pct": 42.857142857142854
}
```
这里列出必验字段，完整结果可能包含额外明细。浮点数绝对/相对容差1e-8，字符串、布尔值、列表必须精确匹配。
脚本返回0表示计算成功并生成两份报告；返回2表示输入不合规并输出JSON错误，不生成新成功报告。请为每次调用使用新的输出目录，以免误读之前的结果。
